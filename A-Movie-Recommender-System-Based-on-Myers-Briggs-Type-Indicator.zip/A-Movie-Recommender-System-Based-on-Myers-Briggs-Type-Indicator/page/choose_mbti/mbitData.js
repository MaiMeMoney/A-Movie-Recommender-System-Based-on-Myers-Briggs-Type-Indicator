const mbtiData = {
    "INTJ": {
        name: "Architect",
        image: "Architect.png",
        quote: "THOUGHT CONSTITUTES THE GREATNESS OF MAN. MAN IS A REED, THE FEEBLEST THING IN NATURE, BUT HE IS A THINKING REED.",
        description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry..."
    },
    "INTP": {
        name: "Logician",
        image: "logician.png",
        quote: "Another quote for INTP",
        description: "Description for INTP..."
    },
    // เพิ่มข้อมูลสำหรับ MBTI อื่นๆ ที่นี่
};